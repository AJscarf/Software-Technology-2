import tkinter as tk
from tkinter import messagebox



class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    # Height
    def height(self, node):
        if not node:
            return 0
        return node.height

    # Balance Factor
    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    # Right Rotation
    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    # Left Rotation
    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    # INSERT (with balancing)
    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        # LL
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        # RR
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        # LR
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        # RL
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    # FIND MIN
    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    # DELETE (with balancing)
    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if not root:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # LL
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        # LR
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # RR
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        # RL
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    # SEARCH
    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    # INORDER
    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result



class AVLApp:
    def __init__(self, master):
        self.tree = AVLTree()
        self.master = master
        master.title("AVL Contact Directory")

        # Input
        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1)

        # Buttons
        btn_frame = tk.Frame(master)
        btn_frame.pack()

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1)
        tk.Button(btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3)

        # Output
        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        # Canvas
        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    # ===== FUNCTIONS =====

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Error", "Enter both fields")
            return

        self.tree.root = self.tree.insert(self.tree.root, name, phone)
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        node = self.tree.search(self.tree.root, name)

        self.output_text.delete(1.0, tk.END)

        if node:
            self.output_text.insert(tk.END, f"Found: {node.name} - {node.phone}")
        else:
            self.output_text.insert(tk.END, "Not found")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        self.tree.root = self.tree.delete(self.tree.root, name)
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)

        for n, p in contacts:
            self.output_text.insert(tk.END, f"{n} - {p}\n")

    # ===== TREE DRAW =====

    def draw_tree(self):
        self.canvas.delete("all")
        self._draw_node(self.tree.root, 400, 30, 200)

    def _draw_node(self, node, x, y, offset):
        if not node:
            return

        r = 20

        if node.left:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw_node(node.left, x - offset, y + 70, offset // 2)

        if node.right:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw_node(node.right, x + offset, y + 70, offset // 2)

        self.canvas.create_oval(x - r, y - r, x + r, y + r, fill="lightgreen")
        self.canvas.create_text(x, y, text=node.name)




if __name__ == "__main__":
    root = tk.Tk()
    app = AVLApp(root)
    root.mainloop()