import tkinter as tk
from tkinter import messagebox
import time
from contact_bst import ContactDirectory


class App:
    def __init__(self, root):
        self.dir = ContactDirectory()
        self.root = root
        root.title("BST Contact Directory")

        tk.Label(root, text="Name").pack()
        self.name = tk.Entry(root)
        self.name.pack()

        tk.Label(root, text="Phone").pack()
        self.phone = tk.Entry(root)
        self.phone.pack()

        tk.Button(root, text="Insert", command=self.insert).pack()
        tk.Button(root, text="Search", command=self.search).pack()
        tk.Button(root, text="Delete", command=self.delete).pack()
        tk.Button(root, text="Show All", command=self.show_all).pack()
        tk.Button(root, text="Benchmark", command=self.benchmark).pack()

        self.output = tk.Text(root)
        self.output.pack()

    def insert(self):
        self.dir.root = self.dir.insert(self.dir.root, self.name.get(), self.phone.get())
        messagebox.showinfo("Inserted", self.name.get())

    def search(self):
        node = self.dir.search(self.dir.root, self.name.get())
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, str(node.phone) if node else "Not found")

    def delete(self):
        self.dir.root = self.dir.delete(self.dir.root, self.name.get())
        messagebox.showinfo("Deleted", self.name.get())

    def show_all(self):
        self.output.delete(1.0, tk.END)
        self.print_all(self.dir.root)

    def print_all(self, root):
        if root:
            self.print_all(root.left)
            self.output.insert(tk.END, f"{root.name} - {root.phone}\n")
            self.print_all(root.right)

    def benchmark(self):
        import random, string
        N = 1000
        names = [''.join(random.choices(string.ascii_lowercase, k=5)) for _ in range(N)]

        start = time.time()
        for n in names:
            self.dir.root = self.dir.insert(self.dir.root, n, "000")
        insert_time = time.time() - start

        self.output.insert(tk.END, f"\nInsert time: {insert_time:.4f}s")


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()