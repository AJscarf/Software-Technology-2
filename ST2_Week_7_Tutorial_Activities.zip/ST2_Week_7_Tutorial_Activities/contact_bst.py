class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name, root.phone = temp.name, temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root):
        if root:
            self.inorder(root.left)
            print(f"Name: {root.name}, Phone: {root.phone}")
            self.inorder(root.right)


# TEST
if __name__ == "__main__":
    d = ContactDirectory()
    d.root = d.insert(d.root, "Alice", "123")
    d.root = d.insert(d.root, "Bob", "234")
    d.root = d.insert(d.root, "Eve", "345")

    print("All contacts:")
    d.inorder(d.root)

    print("\nSearch Bob:")
    print(d.search(d.root, "Bob").phone)

    print("\nDelete Alice:")
    d.root = d.delete(d.root, "Alice")
    d.inorder(d.root)