class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:  # Check that vertices are present
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:  # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        """Remove the edge between vertex1 and vertex2."""
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
                self.weights.pop((vertex1, vertex2), None)
            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
                    self.weights.pop((vertex2, vertex1), None)
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        """Remove a vertex and all edges connected to it."""
        if vertex in self.graph:
            # Remove all edges pointing TO this vertex from other vertices
            for other in self.graph:
                if vertex in self.graph[other]:
                    self.graph[other].remove(vertex)
                    self.weights.pop((other, vertex), None)
            # Remove edges FROM this vertex
            for neighbour in self.graph[vertex]:
                self.weights.pop((vertex, neighbour), None)
            # Delete the vertex itself
            del self.graph[vertex]
        else:
            print(f"Vertex '{vertex}' not found in graph.")

    def print_graph(self):
        """Print the adjacency list, including weights when applicable."""
        graph_type = ("Directed" if self.directed else "Undirected")
        graph_type += " Weighted" if self.weighted else " Unweighted"
        print(f"[{graph_type} Graph]")
        for vertex in self.graph:
            if self.weighted:
                edges = ", ".join(
                    f"{neighbour} (w={self.weights.get((vertex, neighbour), '?')})"
                    for neighbour in self.graph[vertex]
                )
            else:
                edges = ", ".join(self.graph[vertex])
            print(f"  {vertex} -> [{edges}]")
        if not self.graph:
            print("  (empty graph)")
    from collections import deque

    def bfs(self, start_vertex):
        """Perform Breadth-First Search starting from start_vertex."""
        
        if start_vertex not in self.graph:
            print(f"Vertex '{start_vertex}' not found.")
            return []

        visited = set()
        queue = deque([start_vertex])
        traversal_order = []

        while queue:
            current = queue.popleft()

            if current not in visited:
                visited.add(current)
                traversal_order.append(current)

                for neighbour in self.graph[current]:
                    if neighbour not in visited:
                        queue.append(neighbour)

        return traversal_order
    
    def dfs(self, start_vertex):
        """Perform Depth-First Search starting from start_vertex using a stack."""

        if start_vertex not in self.graph:
            print(f"Vertex '{start_vertex}' not found.")
            return []

        visited = set()
        stack = [start_vertex]
        traversal_order = []

        while stack:
            current = stack.pop()

            if current not in visited:
                visited.add(current)
                traversal_order.append(current)

                # Add neighbours to stack (reverse for consistent order)
                for neighbour in reversed(self.graph[current]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return traversal_order
            
    def has_undirected_cycle(self):
        """Detect if the undirected graph contains a cycle using DFS."""
        visited = set()
        for vertex in self.graph:
            if vertex not in visited:
                if self._dfs_cycle(vertex, visited, None):
                    return True
        return False

    def _dfs_cycle(self, vertex, visited, parent):
        visited.add(vertex)
        for neighbor in self.graph[vertex]:
            if neighbor not in visited:
                if self._dfs_cycle(neighbor, visited, vertex):
                    return True
            elif neighbor != parent:
                return True
        return False
            
from collections import deque

