from graph import Graph

# ── Basic undirected graph tests ───────────────────────────────────────────────
print("=" * 50)
print("UNDIRECTED GRAPH")
print("=" * 50)
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('D', 'A')

g.print_graph()
print()

# ── Directed graph tests ───────────────────────────────────────────────────────
print("=" * 50)
print("DIRECTED GRAPH")
print("=" * 50)
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('D', 'A')

g.print_graph()
print()

# ── Weighted directed graph tests ──────────────────────────────────────────────
print("=" * 50)
print("WEIGHTED DIRECTED GRAPH")
print("=" * 50)
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 7)
g.add_edge('D', 'A', 22)

g.print_graph()
print()

# ── Removal tests ──────────────────────────────────────────────────────────────
print("=" * 50)
print("REMOVAL TESTS")
print("=" * 50)
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')

print("Initial graph:")
removal_test.print_graph()
print()

removal_test.remove_edge('A', 'B')
print("After removing edge A-B:")
removal_test.print_graph()
print()

removal_test.remove_vertex('C')
print("After removing vertex C:")
removal_test.print_graph()
print()

# ── Edge case: adding edge with missing vertex ─────────────────────────────────
print("=" * 50)
print("EDGE CASE: missing vertex")
print("=" * 50)
g2 = Graph()
g2.add_vertex('X')
g2.add_edge('X', 'Z')   # Z doesn't exist

# ── BFS TEST ───────────────────────────────────────────────────────────────
print("=" * 50)
print("BFS TEST")
print("=" * 50)

g_bfs = Graph()
g_bfs.add_vertex('A')
g_bfs.add_vertex('B')
g_bfs.add_vertex('C')
g_bfs.add_vertex('D')
g_bfs.add_vertex('E')

# Create a slightly more complex graph
g_bfs.add_edge('A', 'B')
g_bfs.add_edge('A', 'C')
g_bfs.add_edge('B', 'D')
g_bfs.add_edge('C', 'E')

print("Graph:")
g_bfs.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g_bfs.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# ── DFS TEST ───────────────────────────────────────────────────────────────
print("=" * 50)
print("DFS TEST")
print("=" * 50)

g_dfs = Graph()
g_dfs.add_vertex('A')
g_dfs.add_vertex('B')
g_dfs.add_vertex('C')
g_dfs.add_vertex('D')
g_dfs.add_vertex('E')

# Same graph as BFS (important for comparison)
g_dfs.add_edge('A', 'B')
g_dfs.add_edge('A', 'C')
g_dfs.add_edge('B', 'D')
g_dfs.add_edge('C', 'E')

print("Graph:")
g_dfs.print_graph()
print()

print("DFS starting from vertex 'A':")
visited_dfs = g_dfs.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# ── Cycle Detection in Undirected Graphs ──────────────────────────────────────
print("=" * 50)
print("CYCLE DETECTION IN UNDIRECTED GRAPHS")
print("=" * 50)

# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle

print("Cycle graph:")
cycle_graph.print_graph()
print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())
print()

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Acyclic graph:")
acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())

# ── Weighted and Directed Graphs ──────────────────────────────────────────────
print("=" * 50)
print("WEIGHTED AND DIRECTED GRAPHS")
print("=" * 50)

# Create weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()


