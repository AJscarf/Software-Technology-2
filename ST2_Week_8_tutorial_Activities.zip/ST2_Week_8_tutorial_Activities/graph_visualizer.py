# === graph_visualizer.py ===
from graph import Graph
import tkinter as tk
from tkinter import simpledialog
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph

        # Control frame
        self.control_frame = tk.Frame(self)
        self.control_frame.pack(side=tk.TOP, fill=tk.X)

        # Button frame for centering
        self.button_frame = tk.Frame(self.control_frame)
        self.button_frame.pack(expand=True, anchor='center')

        # Add vertex
        tk.Button(self.button_frame, text="Add Vertex", command=self.add_vertex).pack(side=tk.LEFT)
        tk.Button(self.button_frame, text="Remove Vertex", command=self.remove_vertex).pack(side=tk.LEFT)

        # Add edge
        tk.Button(self.button_frame, text="Add Edge", command=self.add_edge).pack(side=tk.LEFT)
        tk.Button(self.button_frame, text="Remove Edge", command=self.remove_edge).pack(side=tk.LEFT)

        # Traversal
        tk.Button(self.button_frame, text="BFS", command=self.bfs_traversal).pack(side=tk.LEFT)
        tk.Button(self.button_frame, text="DFS", command=self.dfs_traversal).pack(side=tk.LEFT)

        self.canvas = tk.Canvas(self, width=600, height=400, bg='white')
        self.canvas.pack(side=tk.TOP)

        self.vertex_positions = {}
        self.highlighted = set()
        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        radius = 20
        spacing = 100
        # Arrange vertices in a circle
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 300, 200
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            color = 'yellow' if v in self.highlighted else 'lightblue'
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)
            self.canvas.create_text(x, y, text=v)

        # Draw edges
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST if self.graph.directed else None)
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def add_vertex(self):
        v = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if v:
            self.graph.add_vertex(v.strip())
            self.draw_graph()

    def remove_vertex(self):
        v = simpledialog.askstring("Remove Vertex", "Enter vertex name:")
        if v:
            self.graph.remove_vertex(v.strip())
            self.draw_graph()

    def add_edge(self):
        v1 = simpledialog.askstring("Add Edge", "Enter from vertex:")
        if not v1:
            return
        v2 = simpledialog.askstring("Add Edge", "Enter to vertex:")
        if not v2:
            return
        w = simpledialog.askstring("Add Edge", "Enter weight (optional):")
        weight = int(w) if w and w.isdigit() else 0
        self.graph.add_edge(v1.strip(), v2.strip(), weight)
        self.draw_graph()

    def remove_edge(self):
        v1 = simpledialog.askstring("Remove Edge", "Enter from vertex:")
        if not v1:
            return
        v2 = simpledialog.askstring("Remove Edge", "Enter to vertex:")
        if not v2:
            return
        self.graph.remove_edge(v1.strip(), v2.strip())
        self.draw_graph()

    def bfs_traversal(self):
        start = simpledialog.askstring("BFS Traversal", "Enter start vertex:")
        if start:
            order = self.graph.bfs(start.strip())
            self.animate_traversal(order)

    def dfs_traversal(self):
        start = simpledialog.askstring("DFS Traversal", "Enter start vertex:")
        if start:
            order = self.graph.dfs(start.strip())
            self.animate_traversal(order)

    def animate_traversal(self, order):
        self.highlighted = set()
        self.draw_graph()
        self._animate_step(order, 0)

    def _animate_step(self, order, index):
        if index < len(order):
            self.highlighted.add(order[index])
            self.draw_graph()
            self.after(500, self._animate_step, order, index + 1)
        else:
            self.after(2000, lambda: setattr(self, 'highlighted', set()) or self.draw_graph())

if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()