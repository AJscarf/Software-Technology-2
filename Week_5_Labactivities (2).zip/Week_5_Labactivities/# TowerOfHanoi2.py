# TowerOfHanoi.py 

moves = 0  # Global variable to count moves

def main():
    global moves
    n = int(input("Enter number of disks: "))
    
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    
    print("Number of Moves is:", moves)


def moveDisks(n, fromTower, toTower, auxTower):
    global moves
    
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
        moves += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        
        print("Move disk", n, "from", fromTower, "to", toTower)
        moves += 1
        
        moveDisks(n - 1, auxTower, toTower, fromTower)


main()