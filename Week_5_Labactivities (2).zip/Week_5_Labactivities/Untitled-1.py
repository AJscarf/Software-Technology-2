# ================== #
# Koch Snowflake #
# ================== #

from tkinter import *
import math

class KochSnowflake:
    def __init__(self): # Fixed: Added double underscores
        window = Tk() 
        window.title("Koch snowflake") # Matches image title

        self.width = 500
        self.height = 500

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        # UI Frame
        frame1 = Frame(window)
        frame1.pack(pady=5)

        # Label and Entry updated to match your screenshot phrasing
        Label(frame1, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()
        self.order.set("0") # Default value
        Entry(frame1, textvariable=self.order, width=5, justify=RIGHT).pack(side=LEFT, padx=5)

        # Button text changed to "Display" to match screenshot
        Button(frame1, text="Display", command=self.draw_snowflake).pack(side=LEFT)

        window.mainloop()

    def draw_snowflake(self):
        self.canvas.delete("all")

        try:
            order = int(self.order.get())
        except:
            order = 0

        # Initial equilateral triangle points
        p1 = (100, 350)
        p2 = (400, 350)
        p3 = (250, 90)

        # Draw 3 sides recursively
        self.koch(order, p1, p2)
        self.koch(order, p2, p3)
        self.koch(order, p3, p1)

    def koch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            x1, y1 = p1
            x5, y5 = p2

            # Divide line into segments
            # Segment 1: 1/3 point
            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3

            # Segment 2: The "Peak" point of the equilateral triangle
            x3 = (x1 + x5) / 2 + math.sqrt(3) * (y1 - y5) / 6
            y3 = (y1 + y5) / 2 + math.sqrt(3) * (x5 - x1) / 6

            # Segment 3: 2/3 point
            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3

            # Recursive calls for the 4 new segments
            self.koch(order - 1, (x1, y1), (x2, y2))
            self.koch(order - 1, (x2, y2), (x3, y3))
            self.koch(order - 1, (x3, y3), (x4, y4))
            self.koch(order - 1, (x4, y4), (x5, y5))

if __name__ == "__main__":
    KochSnowflake()